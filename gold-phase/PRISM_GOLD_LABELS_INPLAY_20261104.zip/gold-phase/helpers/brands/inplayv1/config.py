import os
from datetime import timezone, timedelta

BRAND_KEY = "inplayv1"
BRAND = "inplay"
PLATFORM = "Online"
WALLET_PLATFORM = "Inplay"
DEFAULT_DOMAIN = "www.inplay.com.ph"

# Fixed InplayV1 routing. Keep DB credentials in .env; do not override these via .env.
SOURCE_DB_NAME = "iestdl"
TARGET_DB_NAME = "iestdbrds"
SOURCE_SCHEMA = "kemet"
TARGET_SCHEMA = "public"
SOURCE_MODE = "table_batch"
SOURCE_TABLES = {
    "players": "PlayerRegistrationsInplayV1",
    "player_detail": "PlayerRegistrationsInplayV1",
    "game_transactions": "GameTransactionInplayV1_dmp",
    "deposits": "DepositsInplayV1",
    "withdrawals": "WithdrawalsInplayV1",
}

PLAYER_TABLE = "playerDetails_final"
GAME_TRANSACTION_TABLE = "gameTransaction_prod"
WALLET_TRANSACTION_TABLE = "walletTransaction_prod"
GAME_PROVIDER_TABLE = "gameProvider_final"
GAME_TYPE_TABLE = "gameType_final"
GAME_LIST_TABLE = "gameList_final"
OUTLET_TABLE = "outletList_final"
CHECKPOINT_TABLE = "migration_checkpoint_prod"

BUSINESS_TZ = timezone(timedelta(hours=8))
BUSINESS_TZ_NAME = "Asia/Manila"
BUSINESS_WINDOW_START_HOUR = 6
DEFAULT_MOBILE = "0000000000"
DEFAULT_EMAIL = ""
DEFAULT_ADDRESS = "N/A"
INSERT_PAGE_SIZE = 100
RECON_BATCH_SIZE = 1000
RECON_DETAIL_LIMIT = 500
RECON_MAX_SCAN_ROWS = 0
DQ_SAMPLE_LIMIT = 100


# TRUE: D2S -> Data Lake -> Gold; FALSE: Data Lake -> Gold only.
FULL_ETL = True
