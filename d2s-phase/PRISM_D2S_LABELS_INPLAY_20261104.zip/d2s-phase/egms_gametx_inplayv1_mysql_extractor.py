#!/usr/bin/env python3
"""
Safe EGMS Game Transactions extractor for Python 3.9.

Purpose:
- Extract all rows in a GameDate/UpdateDateTime window from a remote MariaDB/MySQL server.
- Use date-window SQL only; no SQL pagination condition and no SQL LIMIT by default.
- Use a streaming cursor and fetchmany() so Python does not load all rows in memory.
- Use small internal fetch batches, optional sleep, and low OS priority to reduce host impact.
- Write PostgreSQL-ready JSONL.GZ output with shape: id, data, game_dt.
- Treat source MariaDB/MySQL datetime values as UTC/system time and write UTC ISO milliseconds with Z.
- Omit Idx and write data JSON keys in the approved PostgreSQL payload order.
- Do not compute derived jackpot fields in extraction.
  Derived fields such as JACKPOT_PAYOUT and JACKPOT_CONTRIBUTION are handled later by the loader/target layer.
- Validate source database count against generated JSONL row count before PASS.
- Create a manifest with row count, checksum, start/end time, and duration.
- Optional local or SFTP handoff.

Recommended MySQL/MariaDB index:
    CREATE INDEX idx_egms_gamedate ON Artemis.EGMS_Game_Trans (GameDate);

For change-aware extracts:
    CREATE INDEX idx_egms_updatedatetime ON Artemis.EGMS_Game_Trans (UpdateDateTime);

Run example:
    python3.9 egms_games_txn_mysql_extract_utc_source.py \
      --db Artemis \
      --table EGMS_Game_Trans \
      --pwd 'CHANGE_ME' \
      --from '2025-11-28 06:00:00' \
      --to '2025-11-29 06:00:00' \
      --date-column GameDate \
      --dest local
"""

import argparse
import fcntl
import gzip
import hashlib
import json
import logging
# ADDED (SMTP failure alerts): Python standard-library email support.
import os
import subprocess  # ADDED - secure detached loader handoff
import stat  # ADDED - validate loader script permissions
import shutil
import signal
import sys
import time
from dataclasses import dataclass
from datetime import datetime, date, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Optional

import pymysql
from pymysql.cursors import SSDictCursor

try:
    import paramiko
except ImportError:
    paramiko = None


# =============================================================================
# CHANGE VARIABLES HERE
# =============================================================================

# Remote MariaDB/MySQL connection settings (exported by load_config.sh).
MYSQL_HOST = os.environ["DB_SETTINGS_INPLAY1_DB_HOST"]
MYSQL_PORT = int(os.environ["DB_SETTINGS_INPLAY1_DB_PORT"])
MYSQL_USER = os.environ["DB_SETTINGS_INPLAY1_DB_USER"]

DEFAULT_DB = os.environ["DB_SETTINGS_INPLAY1_DB_NAME"]
DEFAULT_TABLE = os.environ["DB_SETTINGS_INPLAY1_GAMETX_TABLENAME"]

# =============================================================================
# SMTP failure alerts are dispatched through common/shared_modules/etl_alert.py.
# The shared module reads SMTP settings from the exported config.toml and .env.
# =============================================================================

# UPDATED - Handoff path variables declared AFTER BASE_DIR/LOG_DIR below.
HANDOFF_STARTUP_SECONDS = 10  # leave it
# ADDED - Standalone extraction switch (same style as SKIP_HISTORY in loader Bash).
# False: after extraction PASS, start the independent PostgreSQL loader (default).
# True : extraction only; do not launch the loader. No success email is sent.
#SKIP_LOADER = False  # leave it
SKIP_LOADER = os.environ.get("SKIP_LOADER", "false").lower() == "true"

# PostgreSQL target mapping:
# target id      = TransactionID
# target data    = JSON payload created from source columns
# target game_dt = GameDate
OUTPUT_ID_COLUMN = os.environ["DB_SETTINGS_INPLAY1_BUSINESS_PRI_ID_COLUMN"]
GAME_DT_OUTPUT_COLUMN = os.environ["DB_SETTINGS_INPLAY1_BUSINESS_DATE_BOUNDARY_COLUMN"]
DEFAULT_DATE_COLUMN = os.environ["DB_SETTINGS_INPLAY1_DEF_BUSINESS_DATE_BOUNDARY_COLUMN"]

# File naming.
FILE_PREFIX = os.environ["DB_SETTINGS_INPLAY1_FILE_PREFIX"]

# Local runtime timestamps still use PHT for log readability only.
from zoneinfo import ZoneInfo
PHT_OFFSET = ZoneInfo(os.environ["COMMON_ETL_SETTINGS_PHT_TIMEZONE"])

# Source business/filter time remains UTC-assumed (no PHT shift).
SOURCE_TIMEZONE = ZoneInfo(os.environ["COMMON_ETL_SETTINGS_SOURCE_TIMEZONE"])

# Local directories from config.toml.
BASE_DIR = Path(os.environ["DIRECT2SILVER_PHASE"])
OUTPUT_DIR = Path(os.environ["DMP_DIR"])
TMP_WORK_DIR = Path(os.environ["TEMP_DRAFTING_DIR"])
#WORK_DIR = BASE_DIR / "work"  # Existing working directory, required by make_run_dir().
LOG_DIR = Path(os.environ["BASE_LOG_DIR"])
LOCK_FILE = Path(os.environ["EXTRACT_LOCK_FILE"])

# Retain original loader handoff and log directory relationships.
LOADER_BASH = BASE_DIR / "batch_daily_loader.sh"
HANDOFF_DIR = LOG_DIR / "loader_handoff"

# Destination.
DEFAULT_DEST = os.environ["STORAGE_DEFAULT_DEST"]

# SFTP settings. Used only when --dest sftp.
SFTP_HOST = os.environ["STORAGE_SFTP_SFTP_HOST"]
SFTP_PORT = int(os.environ["STORAGE_SFTP_SFTP_PORT"])
SFTP_USER = os.environ["STORAGE_SFTP_SFTP_USER"]
SFTP_PRIVATE_KEY = Path(os.environ["STORAGE_SFTP_SFTP_PRIVATE_KEY"]).expanduser()
SFTP_REMOTE_DIR = os.environ["STORAGE_SFTP_SFTP_REMOTE_DIR"]

# Safety controls.
# FETCH_SIZE controls Python memory usage only. It is NOT a total row limit.
FETCH_SIZE = int(os.environ["DB_SETTINGS_INPLAY1_FETCH_SIZE"])
SLEEP_SECONDS_BETWEEN_FETCHES = float(os.environ["COMMON_ETL_SETTINGS_SLEEP_SECONDS_BETWEEN_FETCHES"])
PROGRESS_LOG_EVERY_ROWS = int(os.environ["DB_SETTINGS_INPLAY1_PROGRESS_LOG_EVERY_ROWS"])

# Optional safety cap for testing. Use 0 for unlimited/full extract.
MAX_ROWS_TO_EXTRACT = int(os.environ["COMMON_ETL_SETTINGS_MAX_ROWS_TO_EXTRACT"])

# Lower OS CPU priority where supported. Higher number means lower priority.
ENABLE_OS_NICE = os.environ["COMMON_ETL_SETTINGS_ENABLE_OS_NICE"].lower() == "true"
OS_NICE_INCREMENT = int(os.environ["COMMON_ETL_SETTINGS_OS_NICE_INCREMENT"])

# Disable COUNT(*) by default to avoid extra load on large tables.
ENABLE_SOURCE_COUNT = os.environ["COMMON_ETL_SETTINGS_ENABLE_SOURCE_COUNT"].lower() == "true"

# Retention.
LOCAL_RETENTION_DAYS = int(os.environ["COMMON_ETL_SETTINGS_LOCAL_RETENTION_DAYS"])
LOG_RETENTION_DAYS = int(os.environ["COMMON_ETL_SETTINGS_LOG_RETENTION_DAYS"])

#APP_NAME = "extract_egms_gamestx_safe"
APP_NAME = "egms_games_txn_mysql_extract"
# Shared formatting and stage-specific SQL (no processing behavior changes).
sys.path.insert(0, os.environ["SHARED_MODS"])
from etl_report import configure_logging, print_summary, log_exception
from query import egms_extractor_queries as extractor_queries

# Source columns to SELECT from MariaDB/MySQL.
# Idx is intentionally omitted from the extract payload.
# No computed fields are added in extraction; loader/target layer handles derived fields later.
SOURCE_SELECT_COLUMNS = [
    "JW1",
    "JW2",
    "JW3",
    "JW4",
    "JW5",
    "PC1",
    "PC2",
    "PC3",
    "PC4",
    "PC5",
    "Outlet",
    "GameDate",
    "GameName",
    "SessionID",
    "TotalWins",
    "TotalStakes",
    "GameProvider",
    "PlayerAccount",
    "TransactionID",
    "SEED_MONEY_WON",
    "UpdateDateTime",
    "PROGRESSIVE_CONTRIBUTION_PAID",
    "SEED_MONEY_JACKPOT_WON_OVER_1000",
]

# Exact JSONB data payload order required for PostgreSQL load.
PAYLOAD_COLUMNS = [
    "JW1",
    "JW2",
    "JW3",
    "JW4",
    "JW5",
    "PC1",
    "PC2",
    "PC3",
    "PC4",
    "PC5",
    "Outlet",
    "GameDate",
    "GameName",
    "SessionID",
    "TotalWins",
    "TotalStakes",
    "GameProvider",
    "PlayerAccount",
    "TransactionID",
    "SEED_MONEY_WON",
    "UpdateDateTime",
    "PROGRESSIVE_CONTRIBUTION_PAID",
    "SEED_MONEY_JACKPOT_WON_OVER_1000",
]

# Backward-compatible alias used by some validation logic.
SOURCE_COLUMNS = SOURCE_SELECT_COLUMNS


# =============================================================================
# CONFIG
# =============================================================================

@dataclass
class Config:
    db: str
    table: str
    pwd: str
    window_from: datetime
    window_to: datetime
    date_column: str
    dest: str
    fetch_size: int
    max_rows: int
    # ADDED - One extraction timestamp shared by JSONL, manifest and handoff.
    run_timestamp: str


# =============================================================================
# TIME / LOG HELPERS
# =============================================================================

def now_pht() -> datetime:
    return datetime.now(PHT_OFFSET)


def format_pht(dt: datetime) -> str:
    return dt.astimezone(PHT_OFFSET).strftime("%Y-%m-%d %H:%M:%S")


def format_utc(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def duration_hhmmss(seconds: float) -> str:
    seconds_int = int(round(seconds))
    h = seconds_int // 3600
    m = (seconds_int % 3600) // 60
    s = seconds_int % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def file_date_label(window_from: datetime) -> str:
    # File/folder label must follow the exact UTC --from date used for extraction.
    return window_from.astimezone(timezone.utc).strftime("%Y%m%d")


def parse_datetime_as_utc(value: str) -> datetime:
    """
    Accepts:
      2025-11-28 06:00:00
      2025-11-28T06:00:00
      2025-11-28T06:00:00Z
      2025-11-28T06:00:00+00:00

    If timezone is missing, treat it as UTC because source MariaDB GameDate is UTC/system time.
    """
    v = value.strip().replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(v)
    except ValueError:
        dt = datetime.strptime(v, "%Y-%m-%d %H:%M:%S")

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=SOURCE_TIMEZONE)

    return dt.astimezone(timezone.utc)


def mysql_datetime_utc(dt: datetime) -> str:
    """
    MariaDB/MySQL DATETIME literal in UTC/system time.

    Example input parameter:
        --from '2025-11-28 06:00:00'

    SQL bind value sent to MariaDB:
        2025-11-28 06:00:00
    """
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def setup_logging() -> Path:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_file = LOG_DIR / f"{APP_NAME}_{now_pht().strftime('%Y%m%d_%H%M%S')}_PHT.log"

    configure_logging(log_file)
    return log_file


# =============================================================================
# SAFETY HELPERS
# =============================================================================

def apply_low_priority() -> None:
    if not ENABLE_OS_NICE:
        return
    try:
        os.nice(OS_NICE_INCREMENT)
        logging.info("Applied low OS priority using nice +%s", OS_NICE_INCREMENT)
    except Exception as exc:
        logging.warning("Could not apply OS nice priority: %s", exc)


def acquire_lock():
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    lock_handle = open(str(LOCK_FILE), "w")
    try:
        fcntl.flock(lock_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        lock_handle.write(str(os.getpid()))
        lock_handle.flush()
        return lock_handle
    except IOError:
        raise RuntimeError(f"Another extractor run is already active. Lock file: {LOCK_FILE}")


STOP_REQUESTED = False


def signal_handler(signum, frame):
    global STOP_REQUESTED
    STOP_REQUESTED = True
    logging.warning("Stop requested by signal %s. Finishing current fetch batch then stopping.", signum)


# =============================================================================
# DATA HELPERS
# =============================================================================

def quote_identifier(name: str) -> str:
    allowed = name.replace("_", "").replace("-", "")
    if not allowed.isalnum():
        raise ValueError(f"Unsafe identifier: {name}")
    return f"`{name}`"


def datetime_to_utc_z(value: datetime) -> str:
    """
    Format source MariaDB/MySQL datetime as UTC Z without shifting if it is naive.

    Important:
    - Source GameDate/UpdateDateTime values are already UTC/system time.
    - If MariaDB returns a naive datetime, attach UTC first.
    - Then write ISO milliseconds with Z.

    Example:
        MariaDB UTC: 2025-11-28 06:00:00
        JSON UTC:   2025-11-28T06:00:00.000Z
    """
    if value.tzinfo is None:
        value = value.replace(tzinfo=SOURCE_TIMEZONE)

    value_utc = value.astimezone(timezone.utc)
    return value_utc.strftime("%Y-%m-%dT%H:%M:%S") + f".{int(value_utc.microsecond / 1000):03d}Z"


def serialize_value(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, datetime):
        return datetime_to_utc_z(value)
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def to_decimal(value: Any) -> Decimal:
    if value is None:
        return Decimal("0.000000")
    if isinstance(value, Decimal):
        return value
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError):
        return Decimal("0.000000")


def decimal_6(value: Decimal) -> str:
    return str(value.quantize(Decimal("0.000001")))


def add_computed_fields(payload: dict) -> None:
    jackpot_payout = sum(to_decimal(payload.get(col)) for col in ["JW1", "JW2", "JW3", "JW4", "JW5"])
    jackpot_contribution = sum(to_decimal(payload.get(col)) for col in ["PC1", "PC2", "PC3", "PC4", "PC5"])

    payload["JACKPOT_PAYOUT"] = decimal_6(jackpot_payout)
    payload["JACKPOT_CONTRIBUTION"] = decimal_6(jackpot_contribution)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def count_gzip_jsonl_rows(path: Path) -> int:
    """Count non-empty JSONL rows in the generated gzip file."""
    count = 0
    with gzip.open(path, "rt", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                count += 1
    return count


# =============================================================================
# ARGUMENTS
# =============================================================================

def parse_args() -> Config:
    parser = argparse.ArgumentParser(description="Safe EGMS MariaDB/MySQL UTC date-window extractor.")
    parser.add_argument("--db", default=DEFAULT_DB, help="MySQL/MariaDB database name.")
    parser.add_argument("--table", default=DEFAULT_TABLE, help="MySQL/MariaDB table name.")
    parser.add_argument("--pwd", required=True, help="MySQL/MariaDB password.")
    parser.add_argument("--from", dest="window_from", required=True, help="UTC start datetime. Example: 2025-11-28 06:00:00")
    parser.add_argument("--to", dest="window_to", required=True, help="UTC end datetime. Example: 2025-11-29 06:00:00")
    parser.add_argument("--date-column", default=DEFAULT_DATE_COLUMN, help="Date column filter. Usually GameDate or UpdateDateTime.")
    parser.add_argument("--dest", choices=["local", "sftp"], default=DEFAULT_DEST, help="Output destination: local or sftp.")
    parser.add_argument("--fetch-size", type=int, default=FETCH_SIZE, help="Rows read from cursor at a time. Not total row limit.")
    parser.add_argument("--max-rows", type=int, default=MAX_ROWS_TO_EXTRACT, help="Optional test cap. 0 means unlimited/full extract.")

    args = parser.parse_args()

    window_from = parse_datetime_as_utc(args.window_from)
    window_to = parse_datetime_as_utc(args.window_to)

    if window_to <= window_from:
        raise ValueError("--to must be greater than --from")
    if args.fetch_size <= 0:
        raise ValueError("--fetch-size must be greater than zero")
    if args.date_column not in SOURCE_SELECT_COLUMNS:
        raise ValueError(f"--date-column must be one of SOURCE_SELECT_COLUMNS. Got: {args.date_column}")
    if OUTPUT_ID_COLUMN not in SOURCE_SELECT_COLUMNS:
        raise ValueError(f"OUTPUT_ID_COLUMN {OUTPUT_ID_COLUMN} must exist in SOURCE_SELECT_COLUMNS")
    if GAME_DT_OUTPUT_COLUMN not in SOURCE_SELECT_COLUMNS:
        raise ValueError(f"GAME_DT_OUTPUT_COLUMN {GAME_DT_OUTPUT_COLUMN} must exist in SOURCE_SELECT_COLUMNS")

    return Config(
        db=args.db,
        table=args.table,
        pwd=args.pwd,
        window_from=window_from,
        window_to=window_to,
        date_column=args.date_column,
        dest=args.dest,
        fetch_size=args.fetch_size,
        max_rows=args.max_rows,
        # ADDED - PHT run clock, seconds included to avoid same-minute collisions.
        run_timestamp=now_pht().strftime("%Y%m%d%H%M%S"),
    )


# =============================================================================
# MYSQL / MARIADB
# =============================================================================

def mysql_connection(cfg: Config):
    return pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=cfg.pwd,
        database=cfg.db,
        charset="utf8mb4",
        cursorclass=SSDictCursor,
        autocommit=True,
        connect_timeout=10,
        read_timeout=7200,
        write_timeout=7200,
    )


def build_select_sql(cfg: Config) -> str:
    return extractor_queries.build_select_sql(cfg, SOURCE_SELECT_COLUMNS, quote_identifier)


def get_source_count(conn, cfg: Config) -> Optional[int]:
    if not ENABLE_SOURCE_COUNT:
        return None

    return get_database_window_count(conn, cfg)


def get_database_window_count(conn, cfg: Config) -> int:
    """Count source rows for the exact UTC date window used by the extract."""
    sql = extractor_queries.build_count_sql(cfg, quote_identifier)
    with conn.cursor(pymysql.cursors.DictCursor) as cur:
        cur.execute(sql, (mysql_datetime_utc(cfg.window_from), mysql_datetime_utc(cfg.window_to)))
        row = cur.fetchone()
        return int(row["cnt"])


# =============================================================================
# FILES
# =============================================================================

# UPDATED - Monthly output storage. No change to source query or JSONL rows.
def monthly_output_dir(cfg: Config) -> Path:
    # Business-date month, not the month the extraction happens.
    return OUTPUT_DIR / file_date_label(cfg.window_from)[:6] / file_date_label(cfg.window_from)


def make_run_dir(cfg: Config) -> Path:
    TMP_WORK_DIR.mkdir(parents=True, exist_ok=True)
    # UPDATED - Unique working directory; never remove a previous attempt.
    run_name = f"{FILE_PREFIX}_{file_date_label(cfg.window_from)}_exractdt_{cfg.run_timestamp}"
    run_dir = TMP_WORK_DIR / run_name
    run_dir.mkdir(parents=True, exist_ok=False)
    return run_dir


def output_file_name(cfg: Config) -> str:
    # UPDATED - Keep requested spelling 'exractdt' in filename.
    return (f"{FILE_PREFIX}_{file_date_label(cfg.window_from)}"
            f"_exractdt_{cfg.run_timestamp}.jsonl.gz")


def manifest_file_name(cfg: Config) -> str:
    # UPDATED - Manifest shares the exact run identifier.
    return (f"{FILE_PREFIX}_{file_date_label(cfg.window_from)}"
            f"_exractdt_{cfg.run_timestamp}_manifest.json")


def copy_to_output(run_dir: Path, cfg: Config) -> Path:
    # UPDATED - mkdir -p semantics: succeeds if YYYYMM already exists.
    month_dir = monthly_output_dir(cfg)
    month_dir.mkdir(parents=True, exist_ok=True)
    # UPDATED - Flat monthly directory (no extra per-day child folder).
    # Publish unique validated files without overwriting an older extraction.
    published = []
    try:
        for src in sorted(run_dir.iterdir()):
            if not src.is_file():
                continue
            dst = month_dir / src.name
            # Exclusive creation prevents accidental overwrite on retry.
            with src.open("rb") as in_file, dst.open("xb") as out_file:
                published.append(dst)
                shutil.copyfileobj(in_file, out_file, length=1024 * 1024)
        return month_dir
    except Exception:
        # Remove only files created by this failed publishing attempt.
        for dst in published:
            dst.unlink(missing_ok=True)
        raise


def write_manifest(
    cfg: Config,
    run_dir: Path,
    output_file: Path,
    source_count: Optional[int],
    extracted_count: int,
    output_json_line_count: Optional[int],
    validation_status: str,
    started_at: datetime,
    completed_at: datetime,
) -> Path:
    duration_seconds = (completed_at - started_at).total_seconds()
    manifest = {
        "app_name": APP_NAME,
        "file_name": output_file.name,
        "mysql_host": MYSQL_HOST,
        "mysql_port": MYSQL_PORT,
        "mysql_user": MYSQL_USER,
        "mysql_database": cfg.db,
        "mysql_table": cfg.table,
        "date_column_used_for_extract": cfg.date_column,
        "target_columns": ["id", "data", "game_dt"],
        "payload_columns_order": PAYLOAD_COLUMNS,
        "datetime_output_format": "Source MariaDB/MySQL UTC datetime written as UTC ISO milliseconds with Z",
        "datetime_example": "2025-11-28 06:00:00 UTC -> 2025-11-28T06:00:00.000Z",
        "window_from_utc": format_utc(cfg.window_from),
        "window_to_utc": format_utc(cfg.window_to),
        "source_count": source_count if source_count is not None else "skipped",
        "extracted_count": extracted_count,
        "output_json_line_count": output_json_line_count if output_json_line_count is not None else "not_checked",
        "count_validation_status": validation_status,
        "fetch_size": cfg.fetch_size,
        "max_rows": cfg.max_rows,
        "started_at_pht": format_pht(started_at),
        "completed_at_pht": format_pht(completed_at),
        "duration_seconds": round(duration_seconds, 3),
        "duration_minutes": round(duration_seconds / 60.0, 3),
        "duration_hhmmss": duration_hhmmss(duration_seconds),
        "destination": cfg.dest,
        "computed_fields": "not_computed_in_extraction; handled later by loader/target layer",
        "file": {
            "file_name": output_file.name,
            "size_bytes": output_file.stat().st_size,
            "sha256": sha256_file(output_file),
        },
    }

    manifest_path = run_dir / manifest_file_name(cfg)
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    return manifest_path


# =============================================================================
# SFTP
# =============================================================================

def ensure_sftp_dir(sftp, remote_dir: str) -> None:
    parts = [p for p in remote_dir.strip("/").split("/") if p]
    current = ""
    for part in parts:
        current += f"/{part}"
        try:
            sftp.stat(current)
        except FileNotFoundError:
            sftp.mkdir(current)


def upload_sftp(local_dir: Path) -> None:
    if paramiko is None:
        raise RuntimeError("paramiko is not installed. Run: python3.9 -m pip install paramiko")
    if not SFTP_PRIVATE_KEY.exists():
        raise FileNotFoundError(f"SFTP private key not found: {SFTP_PRIVATE_KEY}")

    key = paramiko.RSAKey.from_private_key_file(str(SFTP_PRIVATE_KEY))
    transport = paramiko.Transport((SFTP_HOST, SFTP_PORT))
    transport.connect(username=SFTP_USER, pkey=key)
    try:
        sftp = paramiko.SFTPClient.from_transport(transport)
        remote_run_dir = f"{SFTP_REMOTE_DIR.rstrip('/')}/{local_dir.name}"
        ensure_sftp_dir(sftp, remote_run_dir)
        for file_path in sorted(local_dir.iterdir()):
            if file_path.is_file():
                remote_path = f"{remote_run_dir}/{file_path.name}"
                logging.info("Uploading to SFTP: %s", remote_path)
                sftp.put(str(file_path), remote_path)
        sftp.close()
    finally:
        transport.close()


# =============================================================================
# CLEANUP
# =============================================================================

def cleanup_old_files(directory: Path, days: int, pattern: str = "*") -> None:
    if days <= 0 or not directory.exists():
        return
    cutoff = time.time() - (days * 86400)
    for path in directory.glob(pattern):
        try:
            if path.is_file() and path.stat().st_mtime < cutoff:
                path.unlink()
            elif path.is_dir() and path.stat().st_mtime < cutoff:
                shutil.rmtree(path)
        except Exception as exc:
            logging.warning("Cleanup failed for %s: %s", path, exc)


# =============================================================================
# EXTRACT
# =============================================================================

def run_extract(cfg: Config) -> None:
    started_at = now_pht()
    run_dir = make_run_dir(cfg)
    output_path = run_dir / output_file_name(cfg)

    logging.info("Started at PHT : %s", format_pht(started_at))
    logging.info("Remote MySQL   : %s:%s", MYSQL_HOST, MYSQL_PORT)
    logging.info("Run directory  : %s", run_dir)
    logging.info("Output file    : %s", output_path.name)
    logging.info("Database       : %s", cfg.db)
    logging.info("Table          : %s", cfg.table)
    logging.info("Date column    : %s", cfg.date_column)
    logging.info("Window from UTC: %s", format_utc(cfg.window_from))
    logging.info("Window to UTC  : %s", format_utc(cfg.window_to))
    logging.info("Fetch size     : %s", cfg.fetch_size)
    logging.info("Max rows       : %s", "unlimited" if cfg.max_rows == 0 else cfg.max_rows)
    logging.info("Destination    : %s", cfg.dest)

    apply_low_priority()

    conn = mysql_connection(cfg)
    extracted_count = 0
    source_count = None
    last_progress_log = 0

    try:
        source_count = get_source_count(conn, cfg)
        if source_count is None:
            logging.info("Source count   : skipped because ENABLE_SOURCE_COUNT=False")
        else:
            logging.info("Source count   : %s", source_count)

        sql = build_select_sql(cfg)
        params = (mysql_datetime_utc(cfg.window_from), mysql_datetime_utc(cfg.window_to))

        logging.info("Executing date-window SELECT with streaming cursor. No SQL LIMIT.")
        logging.info("SQL window bind from UTC: %s", params[0])
        logging.info("SQL window bind to UTC  : %s", params[1])

        with conn.cursor() as cur:
            cur.execute(sql, params)

            with gzip.open(output_path, "wt", encoding="utf-8") as gz:
                while True:
                    if STOP_REQUESTED:
                        logging.warning("Stop requested. Ending extraction after current completed fetch.")
                        break

                    rows = cur.fetchmany(cfg.fetch_size)
                    if not rows:
                        break

                    for row in rows:
                        source_payload = {col: serialize_value(row.get(col)) for col in SOURCE_SELECT_COLUMNS}

                        # Keep the JSONB payload keys in the exact approved order.
                        # Python 3.9 preserves dict insertion order.
                        payload = {col: source_payload.get(col) for col in PAYLOAD_COLUMNS}

                        output_row = {
                            "id": serialize_value(row.get(OUTPUT_ID_COLUMN)),
                            "data": payload,
                            "game_dt": serialize_value(row.get(GAME_DT_OUTPUT_COLUMN)),
                        }

                        gz.write(json.dumps(output_row, ensure_ascii=False, separators=(",", ":")))
                        gz.write("\n")
                        extracted_count += 1

                        if cfg.max_rows > 0 and extracted_count >= cfg.max_rows:
                            logging.warning("Reached --max-rows test cap: %s", cfg.max_rows)
                            break

                    if extracted_count - last_progress_log >= PROGRESS_LOG_EVERY_ROWS:
                        logging.info("Progress       : extracted_count=%s", extracted_count)
                        last_progress_log = extracted_count

                    if cfg.max_rows > 0 and extracted_count >= cfg.max_rows:
                        break

                    if SLEEP_SECONDS_BETWEEN_FETCHES > 0:
                        time.sleep(SLEEP_SECONDS_BETWEEN_FETCHES)

        logging.info("Running final count validation...")
        logging.info("Counting generated JSONL.GZ rows...")
        output_json_line_count = count_gzip_jsonl_rows(output_path)
        logging.info("Output JSONL row count: %s", output_json_line_count)

        logging.info("Counting source database rows for the same UTC window...")
        database_window_count = get_database_window_count(conn, cfg)
        logging.info("Database window count: %s", database_window_count)

        if not (database_window_count == extracted_count == output_json_line_count):
            completed_at = now_pht()
            manifest_path = write_manifest(
                cfg=cfg,
                run_dir=run_dir,
                output_file=output_path,
                source_count=database_window_count,
                extracted_count=extracted_count,
                output_json_line_count=output_json_line_count,
                validation_status="FAIL",
                started_at=started_at,
                completed_at=completed_at,
            )
            logging.info("Manifest written: %s", manifest_path)
            logging.error(
                "FAIL: Count mismatch. database_count=%s extracted_count=%s output_json_line_count=%s",
                database_window_count,
                extracted_count,
                output_json_line_count,
            )
            print_summary("EXTRACT SUMMARY", [
                ("status", "FAIL"),
                ("database_count", database_window_count),
                ("extracted_count", extracted_count),
                ("output_json_line_count", output_json_line_count),
                ("reason", "count mismatch between source database and output JSON file"),
            ])
            raise RuntimeError(
                f"FAIL: Count mismatch. database_count={database_window_count}, "
                f"extracted_count={extracted_count}, output_json_line_count={output_json_line_count}"
            )

        logging.info(
            "PASS: database_count, extracted_count, and output_json_line_count all match: %s",
            database_window_count,
        )

        completed_at = now_pht()
        manifest_path = write_manifest(
            cfg=cfg,
            run_dir=run_dir,
            output_file=output_path,
            source_count=database_window_count,
            extracted_count=extracted_count,
            output_json_line_count=output_json_line_count,
            validation_status="PASS",
            started_at=started_at,
            completed_at=completed_at,
        )
        logging.info("Manifest written: %s", manifest_path)

        # UPDATED - Publish under daily_dump/jsonl/YYYYMM/.
        final_dir = copy_to_output(run_dir, cfg)
        logging.info("Final output directory: %s", final_dir)

        if cfg.dest == "sftp":
            upload_sftp(final_dir)
            logging.info("SFTP upload completed.")

        duration_seconds = (completed_at - started_at).total_seconds()
        logging.info("Completed at PHT: %s", format_pht(completed_at))
        logging.info("Duration        : %.3f minutes (%s)", duration_seconds / 60.0, duration_hhmmss(duration_seconds))
        logging.info("Extraction completed successfully. total_extracted=%s", extracted_count)

        print_summary("EXTRACT SUMMARY", [
            ("status", "PASS"),
            ("database_count", database_window_count),
            ("extracted_count", extracted_count),
            ("output_json_line_count", output_json_line_count),
            ("output_directory", final_dir),
            ("output_file", final_dir / output_path.name),
            ("duration_minutes", f"{duration_seconds / 60.0:.3f}"),
            ("duration_hhmmss", duration_hhmmss(duration_seconds)),
        ])

    finally:
        try:
            conn.close()
        except Exception:
            pass
        if run_dir.exists():
            shutil.rmtree(run_dir, ignore_errors=True)


# =============================================================================
# ADDED - SMTP ALERT WHEN EXTRACTION FAILS
# =============================================================================

# =============================================================================
# ADDED - ASYNCHRONOUS LOADER HANDOFF (NO DQ)
# =============================================================================

def trigger_loader_handoff(cfg: Config) -> None:
    """Run detached loader, validate its first 10 seconds, and return immediately."""
    # run_extract() has returned, so its MySQL connection has already closed.
    business_date = file_date_label(cfg.window_from)
    # UPDATED - Exact unique file in the business-date YYYYMM directory.
    jsonl_file = monthly_output_dir(cfg) / output_file_name(cfg)
    manifest_file = jsonl_file.parent / manifest_file_name(cfg)
    if not jsonl_file.is_file() or jsonl_file.stat().st_size == 0:
        raise RuntimeError(f"Validated extract missing/empty: {jsonl_file}")
    if not manifest_file.is_file():
        raise RuntimeError(f"Extract manifest missing: {manifest_file}")
    manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    if manifest.get("count_validation_status") != "PASS":
        raise RuntimeError(f"Extract manifest is not PASS: {manifest_file}")

    # Check trusted Bash path; a user-controlled/writable script must not be launched.
    script = LOADER_BASH.resolve(strict=True)
    if not script.is_file() or (script.stat().st_mode & (stat.S_IWGRP | stat.S_IWOTH)):
        raise RuntimeError(f"Loader Bash missing or group/world writable: {script}")
    if not (script == LOADER_BASH.absolute()):
        raise RuntimeError("Loader Bash symlink/path redirection is disallowed")

    HANDOFF_DIR.mkdir(parents=True, exist_ok=True)
    run_label = f"{business_date}_{now_pht():%Y%m%d%H%M%S}_{os.getpid()}"
    log_file = HANDOFF_DIR / f"loader_{run_label}.log"
    status_file = HANDOFF_DIR / f"loader_{run_label}.status"
    started_file = HANDOFF_DIR / f"loader_{run_label}.started"
    args = [
        "/usr/bin/bash", str(script), str(jsonl_file),
        mysql_datetime_utc(cfg.window_from), mysql_datetime_utc(cfg.window_to),
        str(status_file), str(started_file),
    ]
    # Secure: argv list, no shell, trusted script path, detached session.
    env = os.environ.copy()  # Preserve all exported PRISM config and .env values.
    if not env["DST_PWD"]:
        raise RuntimeError("DST_PWD is missing from the cron-exported .env")
    with log_file.open("ab") as log:
        process = subprocess.Popen(
            args, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            cwd=str(BASE_DIR), env=env, close_fds=True,
            start_new_session=True, shell=False,
        )
    logging.info("ADDED: Detached loader launched PID=%s log=%s", process.pid, log_file)
    # Poll throughout the startup window, not just once at the end.
    deadline = time.monotonic() + HANDOFF_STARTUP_SECONDS
    while time.monotonic() < deadline:
        rc = process.poll()
        if rc is not None:
            if rc == 0 and status_file.is_file() and status_file.read_text().startswith("PASS"):
                logging.info("Loader completed successfully during startup window.")
                return
            raise RuntimeError(f"Loader stopped during startup (exit={rc}); see {log_file}")
        time.sleep(0.25)
    rc = process.poll()
    if rc is not None:
        if rc == 0 and status_file.is_file() and status_file.read_text().startswith("PASS"):
            return
        raise RuntimeError(f"Loader stopped at handoff (exit={rc}); see {log_file}")
    if not started_file.is_file():
        raise RuntimeError(f"Loader did not signal Python launch within 10s; see {log_file}")
    # A live Bash process plus the marker is only STARTUP ACCEPTED, not loader PASS.
    logging.info("HANDOFF ACCEPTED after %ss: loader still active PID=%s; extractor exiting",
                 HANDOFF_STARTUP_SECONDS, process.pid)


def send_extraction_failure_email(exc: Exception, cfg: Optional[Config]) -> None:
    """Best-effort failure alert through the existing PRISM shared SMTP module."""
    try:
        shared_dir = Path(os.environ["SHARED_MODS"])
        if not (shared_dir / "etl_alert.py").is_file():
            raise FileNotFoundError(f"Shared SMTP module missing: {shared_dir / 'etl_alert.py'}")
        sys.path.insert(0, str(shared_dir))
        try:
            from etl_alert import send_failure
            # Reuse this extractor's existing file log as failure evidence.
            error_log = next(
                (handler.baseFilename for handler in logging.getLogger().handlers
                 if isinstance(handler, logging.FileHandler)), ""
            )
            window_from = format_utc(cfg.window_from) if cfg else "unknown"
            window_to = format_utc(cfg.window_to) if cfg else "unknown"
            sent = send_failure(
                stage="MySQL-DLAKE-EXTRACT",
                entity="gameTransaction",
                window_from=window_from,
                window_to=window_to,
                exit_code=1,
                error_log=error_log,
            )
            if not sent:
                logging.error("Shared SMTP failure notification was not delivered")
        finally:
            if sys.path and sys.path[0] == str(shared_dir):
                sys.path.pop(0)
    except Exception as mail_exc:
        logging.error("SMTP failure notification could not be sent: %s", mail_exc)


# =============================================================================
# MAIN
# =============================================================================

def main() -> int:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    setup_logging()

    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

    lock_handle = None
    # ADDED - Preserve parsed window for failure emails; None for early failures.
    cfg = None
    try:
        cfg = parse_args()
        lock_handle = acquire_lock()
        run_extract(cfg)
        # UPDATED - Only trigger loader when SKIP_LOADER=False.
        # run_extract() has already PASSed and closed the MySQL connection.
        # SKIP_LOADER=True: save validated JSONL/manifest and exit normally.
        if SKIP_LOADER:
            logging.info("STANDALONE EXTRACTION PASS: SKIP_LOADER=True; loader handoff skipped.")
        else:
            # RETAIN - Asynchronous 10-second loader startup handoff.
            trigger_loader_handoff(cfg)
        # UPDATED - Do not delete YYYYMM archive directories based on folder mtime.
        # Retention for monthly archives requires an explicit archive-aware policy.
        # cleanup_old_files(OUTPUT_DIR, LOCAL_RETENTION_DAYS)
        cleanup_old_files(LOG_DIR, LOG_RETENTION_DAYS, "*.log")
        return 0
    except Exception as exc:
        log_exception("Extraction failed", exc, LOG_DIR)
        # ADDED - Email only for failures; original exit code and behavior retained.
        send_extraction_failure_email(exc, cfg)
        return 1
    finally:
        if lock_handle is not None:
            try:
                fcntl.flock(lock_handle, fcntl.LOCK_UN)
                lock_handle.close()
            except Exception:
                pass


if __name__ == "__main__":
    raise SystemExit(main())


