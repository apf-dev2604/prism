#!/usr/bin/env bash
# SOURCE this file, do not execute it: source "$HOME/scripts/nexus_etl_prod/common/config/load_config.sh"
# Requires mikefarah/yq v4 (TOML input) and Python 3.9+ (stdlib JSON parser).

_prism_fail() { printf '[PRISM CONFIG][ERROR] %s\n' "$*" >&2; return 1; }

_prism_load() {
    local config_file="${PRISM_CONFIG_FILE:-$HOME/scripts/nexus_etl_prod/common/config/config.toml}"
    [[ -r "$config_file" ]] || { _prism_fail "Unreadable config: $config_file"; return 1; }
    command -v yq >/dev/null 2>&1 || { _prism_fail 'mikefarah/yq v4 not found'; return 1; }
    command -v python3 >/dev/null 2>&1 || { _prism_fail 'python3 not found'; return 1; }
    # Python safely quotes exports and expands only already-defined config keys.
    # Generate in a command substitution so parse failure cannot partly export values.
    local statements
    statements="$(yq -p=toml -o=json '.' "$config_file" | python3 -c '
import json, os, re, shlex, sys
try:
    data = json.load(sys.stdin)
    ordered = [(section, data.get(section, {})) for section in ("COMMON_PATHS", "PIPELINE_DIR", "DB_SETTINGS", "SMTP")]
    values = {}
    def flatten(d, prefix=""):
        for key, value in d.items():
            if isinstance(value, dict):
                yield from flatten(value, prefix + key + "_")
            else:
                yield prefix + key, value
    # Shared names are exported for paths and top-level config. Nested database names get prefixed.
    for section, obj in ordered:
        for name, val in flatten(obj, "" if section != "DB_SETTINGS" else "DB_SETTINGS_"):
            if section == "DB_SETTINGS" and not name.startswith("DB_SETTINGS_INPLAY1_") and not name.startswith("DB_SETTINGS_DW_RAW_DB_") and not name.startswith("DB_SETTINGS_STG_RAW_DB_") and not name.startswith("DB_SETTINGS_PRD_RAW_DB_") and not name.startswith("DB_SETTINGS_DQ_"):
                name = name.removeprefix("DB_SETTINGS_")
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
                raise ValueError("Invalid setting name: " + name)
            if isinstance(val, list):
                val = ",".join(map(str, val))
            elif isinstance(val, bool):
                val = "true" if val else "false"
            else:
                val = str(val)
            if val.startswith("~/"):
                val = os.path.expanduser(val)
            def substitute(m):
                key = m.group(1) or m.group(2)
                if key not in values:
                    raise ValueError("Unresolved reference $" + key + " in " + name)
                return values[key]
            val = re.sub(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)", substitute, val)
            values[name] = val
    for key, val in values.items():
        print("export " + key + "=" + shlex.quote(val))
except Exception as exc:
    print("PRISM configuration error: " + str(exc), file=sys.stderr)
    sys.exit(1)
')" || { _prism_fail 'Cannot parse config.toml'; return 1; }
    eval "$statements"
    [[ -r "$ENV_FILE" ]] || { _prism_fail "Unreadable secrets file: $ENV_FILE"; return 1; }
    # .env must use trusted Bash-compatible KEY=VALUE lines.
    set -a
    source "$ENV_FILE" || { set +a; _prism_fail 'Failed sourcing .env'; return 1; }
    set +a
    : "${INPLAYV1_SRC_PWD:?Missing INPLAYV1_SRC_PWD in common/.env}"
    : "${DST_PWD:?Missing DST_PWD in common/.env}"
    # Compatibility with existing extractor/DQ programs expecting SRC_PWD.
    export SRC_PWD="$INPLAYV1_SRC_PWD"
    export SMTP_TO="${SMTP_TO:-${MIGRATION_REPORT_TO:-}}"
    export PRISM_CONFIG_LOADED=1
}
_prism_load || return 1
unset -f _prism_load _prism_fail
